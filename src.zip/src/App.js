import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import Home from './Home';
import Books from './Books';
import Library from './Library';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home />}></Route>
        <Route path='/books/:id/library/:id' element={<Books />}></Route>
        <Route path='/library/:id' element={<Library />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
