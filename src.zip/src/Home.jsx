import React from 'react'
import { userData } from './constants';

const {results} = userData;
const Home = () => {
  return (
    <div>
        {results.map((library) => (<p key={library.id}>{library.title}</p>))}
        <a><a/>
    </div>
  );
}

export default Home;